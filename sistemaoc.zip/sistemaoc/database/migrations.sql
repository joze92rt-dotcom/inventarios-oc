-- Crear esquema base para SistemaOC
CREATE TABLE IF NOT EXISTS roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) UNIQUE NOT NULL,
  descripcion VARCHAR(150) DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  email VARCHAR(120) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  rol_id INT NOT NULL,
  activo TINYINT(1) DEFAULT 1,
  ultimo_login DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (rol_id) REFERENCES roles(id)
);

-- Tablas mínimas adicionales (catálogos iniciales)
CREATE TABLE IF NOT EXISTS series_correlativos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  modulo VARCHAR(50) NOT NULL UNIQUE,
  prefijo VARCHAR(10) NOT NULL,
  serie VARCHAR(10) DEFAULT '',
  correlativo INT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS proveedores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ruc VARCHAR(11) UNIQUE NOT NULL,
  razon_social VARCHAR(200) NOT NULL,
  contacto VARCHAR(120),
  telefono VARCHAR(50),
  email VARCHAR(120),
  direccion VARCHAR(250),
  condiciones_pago VARCHAR(120),
  estado TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categorias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS unidades (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(10) UNIQUE NOT NULL,
  nombre VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS insumos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(30) UNIQUE NOT NULL,
  descripcion VARCHAR(250) NOT NULL,
  categoria_id INT NULL,
  unidad_id INT NOT NULL,
  requiere_refrigeracion TINYINT(1) DEFAULT 0,
  vida_util_dias INT DEFAULT NULL,
  stock_minimo DECIMAL(18,3) DEFAULT 0,
  activo TINYINT(1) DEFAULT 1,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id),
  FOREIGN KEY (unidad_id) REFERENCES unidades(id)
);

CREATE TABLE IF NOT EXISTS proveedor_insumo (
  id INT AUTO_INCREMENT PRIMARY KEY,
  proveedor_id INT NOT NULL,
  insumo_id INT NOT NULL,
  precio_unitario DECIMAL(18,4) DEFAULT NULL,
  activo TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_pi (proveedor_id, insumo_id),
  FOREIGN KEY (proveedor_id) REFERENCES proveedores(id),
  FOREIGN KEY (insumo_id) REFERENCES insumos(id)
);

CREATE TABLE IF NOT EXISTS almacenes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(20) UNIQUE NOT NULL,
  nombre VARCHAR(120) NOT NULL,
  es_principal TINYINT(1) DEFAULT 0,
  es_cuarentena TINYINT(1) DEFAULT 0,
  es_refrigerado TINYINT(1) DEFAULT 0,
  ubicacion VARCHAR(120)
);

CREATE TABLE IF NOT EXISTS lotes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  insumo_id INT NOT NULL,
  numero_lote VARCHAR(60) NOT NULL,
  fecha_vencimiento DATE NOT NULL,
  UNIQUE KEY uk_lote (insumo_id, numero_lote),
  FOREIGN KEY (insumo_id) REFERENCES insumos(id)
);

CREATE TABLE IF NOT EXISTS stock_lotes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  almacen_id INT NOT NULL,
  lote_id INT NOT NULL,
  cantidad DECIMAL(18,3) NOT NULL DEFAULT 0,
  estado ENUM('LIBRE','CUARENTENA') DEFAULT 'LIBRE',
  UNIQUE KEY uk_stock (almacen_id, lote_id),
  FOREIGN KEY (almacen_id) REFERENCES almacenes(id),
  FOREIGN KEY (lote_id) REFERENCES lotes(id)
);

CREATE TABLE IF NOT EXISTS requerimientos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(30) UNIQUE NOT NULL,
  solicitante_id INT NOT NULL,
  motivo VARCHAR(200),
  estado ENUM('BORRADOR','REVISION','APROBADO','ATENDIDO','CERRADO','ANULADO') DEFAULT 'BORRADOR',
  observaciones TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (solicitante_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS requerimiento_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  requerimiento_id INT NOT NULL,
  insumo_id INT NOT NULL,
  cantidad_solicitada DECIMAL(18,3) NOT NULL,
  cantidad_atendida DECIMAL(18,3) NOT NULL DEFAULT 0,
  FOREIGN KEY (requerimiento_id) REFERENCES requerimientos(id),
  FOREIGN KEY (insumo_id) REFERENCES insumos(id)
);

CREATE TABLE IF NOT EXISTS ordenes_compra (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(30) UNIQUE NOT NULL,
  proveedor_id INT NOT NULL,
  solicitante_id INT,
  estado ENUM('BORRADOR','APROBACION','EMITIDA','PARCIAL','COMPLETADA','CERRADA','ANULADA') DEFAULT 'BORRADOR',
  fecha DATE NOT NULL,
  fecha_entrega DATE,
  moneda CHAR(3) DEFAULT 'PEN',
  igv_percent DECIMAL(5,2) DEFAULT 18.00,
  subtotal DECIMAL(18,2) DEFAULT 0,
  igv DECIMAL(18,2) DEFAULT 0,
  total DECIMAL(18,2) DEFAULT 0,
  condiciones_pago VARCHAR(120),
  observaciones TEXT,
  FOREIGN KEY (proveedor_id) REFERENCES proveedores(id),
  FOREIGN KEY (solicitante_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS ordenes_compra_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  orden_compra_id INT NOT NULL,
  insumo_id INT NOT NULL,
  unidad_id INT NOT NULL,
  cantidad DECIMAL(18,3) NOT NULL,
  precio_unitario DECIMAL(18,4) NOT NULL,
  igv_incluido TINYINT(1) DEFAULT 0,
  total_linea DECIMAL(18,2) NOT NULL,
  FOREIGN KEY (orden_compra_id) REFERENCES ordenes_compra(id),
  FOREIGN KEY (insumo_id) REFERENCES insumos(id),
  FOREIGN KEY (unidad_id) REFERENCES unidades(id)
);

CREATE TABLE IF NOT EXISTS notas_ingreso (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(30) UNIQUE NOT NULL,
  orden_compra_id INT,
  proveedor_id INT NOT NULL,
  almacen_id INT NOT NULL,
  estado ENUM('BORRADOR','REGISTRADO','ANULADO') DEFAULT 'BORRADOR',
  fecha DATE NOT NULL,
  observaciones TEXT,
  guia_serie VARCHAR(20),
  guia_numero VARCHAR(20),
  guia_fecha DATE,
  factura_tipo ENUM('FACTURA','BOLETA','NC','ND') DEFAULT NULL,
  factura_serie VARCHAR(20) DEFAULT NULL,
  factura_numero VARCHAR(20) DEFAULT NULL,
  factura_fecha DATE DEFAULT NULL,
  factura_moneda CHAR(3) DEFAULT NULL,
  factura_total DECIMAL(18,2) DEFAULT NULL,
  FOREIGN KEY (orden_compra_id) REFERENCES ordenes_compra(id),
  FOREIGN KEY (proveedor_id) REFERENCES proveedores(id),
  FOREIGN KEY (almacen_id) REFERENCES almacenes(id)
);

CREATE TABLE IF NOT EXISTS notas_ingreso_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nota_ingreso_id INT NOT NULL,
  insumo_id INT NOT NULL,
  numero_lote VARCHAR(60) NOT NULL,
  fecha_vencimiento DATE NOT NULL,
  cantidad DECIMAL(18,3) NOT NULL,
  a_cuarentena TINYINT(1) DEFAULT 0,
  FOREIGN KEY (nota_ingreso_id) REFERENCES notas_ingreso(id),
  FOREIGN KEY (insumo_id) REFERENCES insumos(id)
);

CREATE TABLE IF NOT EXISTS movimientos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(30) UNIQUE NOT NULL,
  tipo ENUM('INGRESO','SALIDA','TRANSFERENCIA') NOT NULL,
  motivo VARCHAR(120),
  almacen_origen_id INT,
  almacen_destino_id INT,
  fecha DATETIME NOT NULL,
  referencia_tipo VARCHAR(30),
  referencia_id INT,
  observaciones TEXT,
  FOREIGN KEY (almacen_origen_id) REFERENCES almacenes(id),
  FOREIGN KEY (almacen_destino_id) REFERENCES almacenes(id)
);

CREATE TABLE IF NOT EXISTS movimiento_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  movimiento_id INT NOT NULL,
  insumo_id INT NOT NULL,
  lote_id INT NOT NULL,
  cantidad DECIMAL(18,3) NOT NULL,
  FOREIGN KEY (movimiento_id) REFERENCES movimientos(id),
  FOREIGN KEY (insumo_id) REFERENCES insumos(id),
  FOREIGN KEY (lote_id) REFERENCES lotes(id)
);

CREATE TABLE IF NOT EXISTS bajas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(30) UNIQUE NOT NULL,
  almacen_id INT NOT NULL,
  motivo VARCHAR(120),
  fecha DATETIME NOT NULL,
  observaciones TEXT,
  estado ENUM('PENDIENTE','APROBADA','ANULADA') DEFAULT 'PENDIENTE',
  FOREIGN KEY (almacen_id) REFERENCES almacenes(id)
);

CREATE TABLE IF NOT EXISTS baja_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  baja_id INT NOT NULL,
  insumo_id INT NOT NULL,
  lote_id INT NOT NULL,
  cantidad DECIMAL(18,3) NOT NULL,
  FOREIGN KEY (baja_id) REFERENCES bajas(id),
  FOREIGN KEY (insumo_id) REFERENCES insumos(id),
  FOREIGN KEY (lote_id) REFERENCES lotes(id)
);
