-- Roles base
INSERT INTO roles (nombre, descripcion) VALUES
('ADMIN','Administrador'),
('JEFE_LOGISTICA','Jefe de Logística'),
('PRODUCCION','Producción');

-- Usuario admin: admin@sistemaoc.local / admin123
INSERT INTO usuarios (nombre, email, password_hash, rol_id, activo)
VALUES ('Administrador', 'admin@sistemaoc.local', 
        '$2y$10$5x4iZa6qJw2e.3l2h1j2qOa0tYb8g8jB95Tt0JX8bQ7b1Gqk6mHqy',
        1, 1);
-- Nota: el hash corresponde a la contraseña: admin123

-- Series iniciales
INSERT INTO series_correlativos (modulo, prefijo, correlativo) VALUES
('OC','OC-',0), ('REQ','REQ-',0), ('NI','NI-',0), ('MV','MV-',0), ('BA','BA-',0), ('ALM','A',0);

-- Unidades básicas
INSERT INTO unidades (codigo, nombre) VALUES ('UND','Unidad'), ('KG','Kilogramo'), ('L','Litro'), ('ML','Mililitro');
