# SistemaOC (MVP)

Sistema básico en **PHP + MySQL** (compatible con **XAMPP**) con **login** y layout **AdminLTE 3** listo para extender a Inventarios + Órdenes de Compra.

## 🚀 Instalación rápida (XAMPP)

1. Clona o copia la carpeta `sistemaoc` dentro de `htdocs`.
2. Crea la base de datos `sistemaoc` en phpMyAdmin.
3. Importa `database/migrations.sql` y luego `database/seeds.sql`.
4. Revisa `app/config/config.php` y ajusta `BASE_URL` si tu ruta es diferente.
5. Navega a: `http://localhost/sistemaoc/public/index.php?c=auth&a=login`

**Credenciales iniciales**
- Email: `admin@sistemaoc.local`
- Contraseña: `admin123`

## 📁 Estructura
```
sistemaoc/
  public/
    index.php           # Front controller y router simple (c & a)
    assets/             # CSS/JS/IMG
  app/
    config/             # Config global + PDO
    core/               # Base Controller + Auth
    controllers/        # Auth, Dashboard
    models/             # Usuario, Rol
    views/              # Layout AdminLTE + login + dashboard
  database/
    migrations.sql      # Esquema base completo
    seeds.sql           # Datos iniciales (roles, admin, series, unidades)
```

## 🧩 Notas
- El layout usa **CDN** de Bootstrap 4.6, FontAwesome 5 y AdminLTE 3.2.
- Router simple vía `index.php?c=controlador&a=accion`.
- Sesiones y autenticación básica con `password_hash`/`password_verify`.

## 🛠️ Próximos pasos
- Agregar controladores y vistas para Insumos, Proveedores, Almacenes, OC, NI, Requerimientos.
- Implementar permisos por rol (ADMIN, JEFE_LOGISTICA, PRODUCCION) en cada acción.
- Agregar generador de códigos con prefijos (series_correlativos) y Kardex.
- Exportaciones PDF/XLSX.
