<?php
// Configuración base
define('BASE_URL', 'http://localhost/sistemaoc/public/');

date_default_timezone_set('America/Lima');

// Iniciar sesión globalmente
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
