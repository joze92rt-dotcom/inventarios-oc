<?php
require_once __DIR__ . '/../config/database.php';

class Rol {
    private $pdo;
    public function __construct() {
        $this->pdo = Database::getConnection();
    }
}
