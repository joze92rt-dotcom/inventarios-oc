<?php
require_once __DIR__ . '/../config/database.php';

class Usuario {
    private $pdo;
    public function __construct() {
        $this->pdo = Database::getConnection();
    }

    public function findByEmail($email) {
        $sql = "SELECT u.*, r.nombre AS rol_nombre FROM usuarios u JOIN roles r ON u.rol_id = r.id WHERE u.email = ? AND u.activo = 1 LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$email]);
        return $stmt->fetch();
    }
}
