<?php
require_once __DIR__ . '/../config/config.php';

class Auth {
    public static function check() {
        return isset($_SESSION['user']);
    }

    public static function user() {
        return $_SESSION['user'] ?? null;
    }

    public static function role() {
        return $_SESSION['user']['rol'] ?? null;
    }

    public static function requireLogin() {
        if (!self::check()) {
            header('Location: ' . BASE_URL . 'index.php?c=auth&a=login');
            exit;
        }
    }

    public static function logout() {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }
        session_destroy();
    }
}
