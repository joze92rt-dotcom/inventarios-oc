<?php
require_once __DIR__ . '/../config/config.php';

class Controller {
    protected function render($viewPath, $data = []) {
        extract($data);
        // $viewPath like 'dashboard/index.php'
        $fullViewPath = __DIR__ . '/../views/' . $viewPath;
        if (!file_exists($fullViewPath)) {
            http_response_code(404);
            echo '<h3>Vista no encontrada: ' . htmlspecialchars($viewPath) . '</h3>';
            return;
        }
        include __DIR__ . '/../views/layouts/adminlte_main.php';
    }

    protected function renderPlain($viewPath, $data = []) {
        extract($data);
        $fullViewPath = __DIR__ . '/../views/' . $viewPath;
        if (!file_exists($fullViewPath)) {
            http_response_code(404);
            echo '<h3>Vista no encontrada: ' . htmlspecialchars($viewPath) . '</h3>';
            return;
        }
        include $fullViewPath;
    }
}
