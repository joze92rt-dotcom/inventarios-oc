<div class="row">
  <div class="col-lg-3 col-6">
    <div class="small-box bg-info">
      <div class="inner">
        <h3>0</h3>
        <p>Órdenes de Compra</p>
      </div>
      <div class="icon"><i class="fas fa-file-invoice"></i></div>
      <a href="#" class="small-box-footer">Ver más <i class="fas fa-arrow-circle-right"></i></a>
    </div>
  </div>
  <div class="col-lg-3 col-6">
    <div class="small-box bg-success">
      <div class="inner">
        <h3>0</h3>
        <p>Notas de Ingreso</p>
      </div>
      <div class="icon"><i class="fas fa-truck-loading"></i></div>
      <a href="#" class="small-box-footer">Ver más <i class="fas fa-arrow-circle-right"></i></a>
    </div>
  </div>
  <div class="col-lg-3 col-6">
    <div class="small-box bg-warning">
      <div class="inner">
        <h3>0</h3>
        <p>Requerimientos</p>
      </div>
      <div class="icon"><i class="fas fa-clipboard-list"></i></div>
      <a href="#" class="small-box-footer">Ver más <i class="fas fa-arrow-circle-right"></i></a>
    </div>
  </div>
  <div class="col-lg-3 col-6">
    <div class="small-box bg-danger">
      <div class="inner">
        <h3>0</h3>
        <p>Alertas de Stock</p>
      </div>
      <div class="icon"><i class="fas fa-exclamation-triangle"></i></div>
      <a href="#" class="small-box-footer">Ver más <i class="fas fa-arrow-circle-right"></i></a>
    </div>
  </div>
</div>
