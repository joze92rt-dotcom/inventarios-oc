<?php
require_once __DIR__ . '/../../config/config.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login | SistemaOC</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
  <style>
    body { background: #f4f6f9; }
    .login-box { max-width: 420px; margin: 8vh auto; }
    .card { border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,.05); }
    .brand { text-align:center; margin-top: 10px; }
    .brand img { width: 64px; height: 64px; }
  </style>
</head>
<body>
<div class="login-box">
  <div class="card">
    <div class="card-body">
      <div class="brand">
        <img src="<?= BASE_URL ?>assets/img/logo.png" alt="logo"/>
        <h4 class="mt-2 mb-4">SistemaOC</h4>
      </div>
      <?php if (!empty($error)): ?>
        <div class="alert alert-danger py-2"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <form method="post" action="<?= BASE_URL ?>index.php?c=auth&a=login">
        <div class="form-group">
          <label>Email</label>
          <input type="email" class="form-control" name="email" placeholder="admin@sistemaoc.local" required>
        </div>
        <div class="form-group">
          <label>Contraseña</label>
          <input type="password" class="form-control" name="password" placeholder="••••••••" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Ingresar</button>
      </form>
    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
