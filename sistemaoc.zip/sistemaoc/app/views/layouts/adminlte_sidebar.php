<?php
require_once __DIR__ . '/../../core/Auth.php';
$user = Auth::user();
$rol = Auth::role();
?>
<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <a href="<?= BASE_URL ?>index.php?c=dashboard&a=index" class="brand-link">
    <img src="<?= BASE_URL ?>assets/img/logo.png" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light">SistemaOC</span>
  </a>
  <div class="sidebar">
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <i class="fas fa-user-circle fa-2x text-white"></i>
      </div>
      <div class="info">
        <a href="#" class="d-block"><?= htmlspecialchars($user['nombre'] ?? 'Usuario') ?> <small class="badge badge-info ml-1"><?= htmlspecialchars($rol ?? '') ?></small></a>
      </div>
    </div>

    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item">
          <a href="<?= BASE_URL ?>index.php?c=dashboard&a=index" class="nav-link">
            <i class="nav-icon fas fa-home"></i>
            <p>Dashboard</p>
          </a>
        </li>

        <li class="nav-header">Inventario</li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon fas fa-warehouse"></i>
            <p>Stock por Almacén</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon fas fa-boxes"></i>
            <p>Insumos</p>
          </a>
        </li>

        <li class="nav-header">Compras</li>
        <li class="nav-item">
          <a href="#" class="nav-link"><i class="nav-icon fas fa-file-invoice"></i><p>Órdenes de Compra</p></a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link"><i class="nav-icon fas fa-truck-loading"></i><p>Ingresos (NI)</p></a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link"><i class="nav-icon fas fa-people-carry"></i><p>Proveedores</p></a>
        </li>

        <li class="nav-header">Producción</li>
        <li class="nav-item">
          <a href="#" class="nav-link"><i class="nav-icon fas fa-clipboard-list"></i><p>Requerimientos</p></a>
        </li>

        <li class="nav-header">Reportes</li>
        <li class="nav-item"><a href="#" class="nav-link"><i class="nav-icon fas fa-chart-bar"></i><p>Reportes</p></a></li>

        <?php if ($rol === 'ADMIN' || $rol === 'JEFE_LOGISTICA'): ?>
        <li class="nav-header">Configuración</li>
        <li class="nav-item"><a href="#" class="nav-link"><i class="nav-icon fas fa-cogs"></i><p>Parámetros</p></a></li>
        <li class="nav-item"><a href="#" class="nav-link"><i class="nav-icon fas fa-users-cog"></i><p>Usuarios & Roles</p></a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>
</aside>
