  <footer class="main-footer text-sm">
    <div class="float-right d-none d-sm-inline">v0.1</div>
    <strong>&copy; <?= date('Y') ?> SistemaOC.</strong> Todos los derechos reservados.
  </footer>
</div>

<!-- REQUIRED SCRIPTS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/app.js"></script>
</body>
</html>
