<?php
require_once __DIR__ . '/../../core/Auth.php';
Auth::requireLogin();
include __DIR__ . '/adminlte_header.php';
include __DIR__ . '/adminlte_sidebar.php';
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6"><h1 class="m-0 text-dark">Panel</h1></div>
      </div>
    </div>
  </div>
  <section class="content">
    <div class="container-fluid">
      <?php include $fullViewPath; ?>
    </div>
  </section>
</div>

<?php include __DIR__ . '/adminlte_footer.php'; ?>
