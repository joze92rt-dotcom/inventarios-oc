<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';

class DashboardController extends Controller {
    public function index() {
        Auth::requireLogin();
        $user = Auth::user();
        $this->render('dashboard/index.php', ['user' => $user]);
    }
}
