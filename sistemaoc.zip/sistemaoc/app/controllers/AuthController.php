<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/Usuario.php';

class AuthController extends Controller {
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = trim($_POST['password'] ?? '');

            $usuarioModel = new Usuario();
            $user = $usuarioModel->findByEmail($email);
            if ($user && password_verify($password, $user['password_hash'])) {
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'nombre' => $user['nombre'],
                    'email' => $user['email'],
                    'rol' => $user['rol_nombre']
                ];
                header('Location: ' . BASE_URL . 'index.php?c=dashboard&a=index');
                exit;
            } else {
                $error = 'Credenciales inválidas';
            }
        }
        $this->renderPlain('auth/login.php', isset($error) ? ['error' => $error] : []);
    }

    public function logout() {
        Auth::logout();
        header('Location: ' . BASE_URL . 'index.php?c=auth&a=login');
        exit;
    }
}
