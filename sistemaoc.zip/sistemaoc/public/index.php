<?php
require_once __DIR__ . '/../app/config/config.php';

// Simple router via query string
$c = strtolower($_GET['c'] ?? 'dashboard');
$a = strtolower($_GET['a'] ?? 'index');

$controllerClass = ucfirst($c) . 'Controller';
$controllerFile = __DIR__ . '/../app/controllers/' . $controllerClass . '.php';

if (!file_exists($controllerFile)) {
    http_response_code(404);
    echo "Controlador no encontrado";
    exit;
}
require_once $controllerFile;

$controller = new $controllerClass();
if (!method_exists($controller, $a)) {
    http_response_code(404);
    echo "Acción no encontrada";
    exit;
}

$controller->$a();
