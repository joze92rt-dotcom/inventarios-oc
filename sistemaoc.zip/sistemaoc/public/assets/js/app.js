// JS global del sistema
